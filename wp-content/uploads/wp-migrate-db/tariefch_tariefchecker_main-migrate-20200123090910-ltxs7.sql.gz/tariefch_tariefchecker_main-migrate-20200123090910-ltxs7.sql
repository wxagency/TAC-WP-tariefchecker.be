# WordPress MySQL database migration
#
# Generated: Thursday 23. January 2020 09:09 UTC
# Hostname: localhost
# Database: `tariefch_tariefchecker_main`
# URL: //litespeed.tariefchecker.be
# Path: /
# Tables: tf_commentmeta, tf_comments, tf_display_files, tf_duplicator_packages, tf_fileaway_downloads, tf_fileaway_metadata, tf_icl_cms_nav_cache, tf_icl_content_status, tf_icl_core_status, tf_icl_flags, tf_icl_languages, tf_icl_languages_translations, tf_icl_locale_map, tf_icl_message_status, tf_icl_mo_files_domains, tf_icl_node, tf_icl_reminders, tf_icl_string_packages, tf_icl_string_pages, tf_icl_string_positions, tf_icl_string_status, tf_icl_string_translations, tf_icl_string_urls, tf_icl_strings, tf_icl_translate, tf_icl_translate_job, tf_icl_translation_batches, tf_icl_translation_status, tf_icl_translations, tf_imagify_files, tf_imagify_folders, tf_layerslider, tf_layerslider_revisions, tf_links, tf_mcloud_task, tf_mcloud_task_data, tf_mcloud_task_schedule, tf_nf3_action_meta, tf_nf3_actions, tf_nf3_chunks, tf_nf3_field_meta, tf_nf3_fields, tf_nf3_form_meta, tf_nf3_forms, tf_nf3_object_meta, tf_nf3_objects, tf_nf3_relationships, tf_nf3_upgrades, tf_options, tf_postmeta, tf_posts, tf_rank_math_404_logs, tf_rank_math_internal_links, tf_rank_math_internal_meta, tf_rank_math_redirections, tf_rank_math_redirections_cache, tf_rank_math_sc_analytics, tf_red_file_manager, tf_revslider_css, tf_revslider_layer_animations, tf_revslider_navigations, tf_revslider_sliders, tf_revslider_slides, tf_revslider_static_slides, tf_strong_views, tf_term_relationships, tf_term_taxonomy, tf_termmeta, tf_terms, tf_usermeta, tf_users, tf_wfBlockedIPLog, tf_wfBlocks7, tf_wfConfig, tf_wfCrawlers, tf_wfFileChanges, tf_wfFileMods, tf_wfHits, tf_wfHoover, tf_wfIssues, tf_wfKnownFileList, tf_wfLiveTrafficHuman, tf_wfLocs, tf_wfLogins, tf_wfNotifications, tf_wfPendingIssues, tf_wfReverseCache, tf_wfSNIPCache, tf_wfStatus, tf_wfTrafficRates, tf_wfls_2fa_secrets, tf_wfls_settings, tf_yoast_seo_links, tf_yoast_seo_meta
# Table Prefix: tf_
# Post Types: revision, acf-field, acf-field-group, attachment, custom_css, nav_menu_item, nf_sub, oembed_cache, page, post, vc_grid_item
# Protocol: https
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `tf_commentmeta`
#

DROP TABLE IF EXISTS `tf_commentmeta`;


#
# Table structure of table `tf_commentmeta`
#

CREATE TABLE `tf_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `tf_commentmeta`
#
INSERT INTO `tf_commentmeta` ( `meta_id`, `comment_id`, `meta_key`, `meta_value`) VALUES
(69, 67, '_wp_trash_meta_status', '0'),
(70, 67, '_wp_trash_meta_time', '1577627100'),
(71, 66, '_wp_trash_meta_status', '0'),
(72, 66, '_wp_trash_meta_time', '1577627100'),
(73, 65, '_wp_trash_meta_status', '0'),
(74, 65, '_wp_trash_meta_time', '1577627100'),
(75, 64, '_wp_trash_meta_status', '0'),
(76, 64, '_wp_trash_meta_time', '1577627100'),
(77, 63, '_wp_trash_meta_status', '0'),
(78, 63, '_wp_trash_meta_time', '1577627100'),
(79, 62, '_wp_trash_meta_status', '0'),
(80, 62, '_wp_trash_meta_time', '1577627100'),
(81, 59, '_wp_trash_meta_status', '0'),
(82, 59, '_wp_trash_meta_time', '1577627100'),
(83, 58, '_wp_trash_meta_status', '0'),
(84, 58, '_wp_trash_meta_time', '1577627100'),
(85, 57, '_wp_trash_meta_status', '0'),
(86, 57, '_wp_trash_meta_time', '1577627100'),
(87, 56, '_wp_trash_meta_status', '0'),
(88, 56, '_wp_trash_meta_time', '1577627100'),
(89, 55, '_wp_trash_meta_status', '0'),
(90, 55, '_wp_trash_meta_time', '1577627100'),
(91, 54, '_wp_trash_meta_status', '0'),
(92, 54, '_wp_trash_meta_time', '1577627100'),
(93, 53, '_wp_trash_meta_status', '0'),
(94, 53, '_wp_trash_meta_time', '1577627100'),
(95, 52, '_wp_trash_meta_status', '0'),
(96, 52, '_wp_trash_meta_time', '1577627100'),
(97, 51, '_wp_trash_meta_status', '0'),
(98, 51, '_wp_trash_meta_time', '1577627100'),
(99, 50, '_wp_trash_meta_status', '0'),
(100, 50, '_wp_trash_meta_time', '1577627100'),
(101, 49, '_wp_trash_meta_status', '0'),
(102, 49, '_wp_trash_meta_time', '1577627100'),
(103, 48, '_wp_trash_meta_status', '0'),
(104, 48, '_wp_trash_meta_time', '1577627100'),
(105, 47, '_wp_trash_meta_status', '0'),
(106, 47, '_wp_trash_meta_time', '1577627100'),
(107, 46, '_wp_trash_meta_status', '0'),
(108, 46, '_wp_trash_meta_time', '1577627121'),
(109, 45, '_wp_trash_meta_status', '0'),
(110, 45, '_wp_trash_meta_time', '1577627121'),
(111, 44, '_wp_trash_meta_status', '0'),
(112, 44, '_wp_trash_meta_time', '1577627121'),
(113, 43, '_wp_trash_meta_status', '0'),
(114, 43, '_wp_trash_meta_time', '1577627121'),
(115, 42, '_wp_trash_meta_status', '0'),
(116, 42, '_wp_trash_meta_time', '1577627121'),
(117, 40, '_wp_trash_meta_status', '0'),
(118, 40, '_wp_trash_meta_time', '1577627121'),
(119, 39, '_wp_trash_meta_status', '0'),
(120, 39, '_wp_trash_meta_time', '1577627121'),
(121, 38, '_wp_trash_meta_status', '0'),
(122, 38, '_wp_trash_meta_time', '1577627121') ;

#
# End of data contents of table `tf_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `tf_comments`
#

DROP TABLE IF EXISTS `tf_comments`;


#
# Table structure of table `tf_comments`
#

CREATE TABLE `tf_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=MyISAM AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `tf_comments`
#
INSERT INTO `tf_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1601, 'KelAwaimi', 'kelPayday@delays.space', 'http://gnplls.com', '5.188.84.130', '2019-11-14 08:01:59', '2019-11-14 07:01:59', 'Cialis En Jovenes Discount Drugs Of Canada Lasix Indication  <a href="http://costofvia.com" rel="nofollow ugc">viagra</a> Viagra Prix Forum Can Clamydia Meds Be Bought Online Order Neurontine Overnight', 0, 'spam', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '', 0, 0),
(2, 1913, 'https://ericsundwall.com/tarot-card-reading-and-meanings/', 'caitlynfoster@gmail.com', 'https://ericsundwall.com/tarot-card-reading-and-meanings/', '209.99.136.36', '2019-11-25 11:38:38', '2019-11-25 10:38:38', 'Ericsundwall.com tarot card meanings pdf https://ericsundwall.com/tarot-card-reading-and-meanings/ Ericsundwall.com one card tarot reading', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.79 Safari/537.36', '', 0, 0),
(3, 1601, 'KelAwaimi', 'kelPayday@delays.space', 'http://buyoxys.com', '5.188.84.130', '2019-11-25 17:14:59', '2019-11-25 16:14:59', 'Levitra Pills Compra Cialis Foro  <a href="http://cialvia.com" rel="nofollow ugc">canadian pharmacy cialis 20mg</a> Kamagra Prescription', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '', 0, 0),
(4, 1750, 'Richelle Rico', 'amail@lmail.website', 'http://bpdrugs.com', '5.188.84.130', '2019-11-28 03:29:28', '2019-11-28 02:29:28', 'What\'s up to all, the contents existing at this website are truly awesome for people knowledge,\r\nwell, keep up the nice work fellows.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36,gzip(gfe)', '', 0, 0),
(5, 1750, 'Melody Doorly', 'amail@lmail.website', 'http://cialcheap.com', '5.188.84.130', '2019-11-29 22:29:35', '2019-11-29 21:29:35', 'After looking at a handful of the blog posts on your web site, I really like your way of writing a blog.\r\nI book marked it to my bookmark webpage list and will be checking back in the near future.\r\nTake a look at my web site as well and let me know your opinion.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36', '', 0, 0),
(6, 1750, 'Blake Swader', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.120', '2019-12-02 04:36:44', '2019-12-02 03:36:44', 'Thanks for a marvelous posting! I genuinely enjoyed reading it, you will be a great author.I will make sure to \r\nbookmark your blog and will eventually come back sometime soon. I want to encourage you to continue your great work, have a \r\nnice holiday weekend!', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.79 Safari/537.36', '', 0, 0),
(7, 1750, 'Agueda Dugas', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.120', '2019-12-03 04:50:30', '2019-12-03 03:50:30', 'Aw, this was an exceptionally good post. Spending some time and actual effort to create a very good article… \r\nbut what can I say… I hesitate a whole lot and don\'t manage to get nearly anything done.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36', '', 0, 0),
(8, 1750, 'Marc Majors', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.120', '2019-12-04 03:55:59', '2019-12-04 02:55:59', 'Useful info. Fortunate me I found your web site by chance, and \r\nI am shocked why this coincidence did not happened earlier!\r\nI bookmarked it.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36,gzip(gfe)', '', 0, 0),
(9, 1750, 'Joshua Willey', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.120', '2019-12-04 11:58:30', '2019-12-04 10:58:30', 'Good replies in return of this issue with real arguments and telling the whole thing regarding that.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36,gzip(gfe)', '', 0, 0),
(10, 1750, 'Aileen Sherriff', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.120', '2019-12-04 17:02:12', '2019-12-04 16:02:12', 'I was able to find good advice from your content.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36,gzip(gfe)', '', 0, 0),
(11, 1715, 'ocourin', 'etabevo@gmail.com', 'http://mewkid.net/buy-phicalis/#eelviyd-w', '195.154.222.29', '2019-12-05 07:43:35', '2019-12-05 06:43:35', 'd3d3LnRhcmllZmNoZWNrZXIuYmU# <a href=\'http://mewkid.net/buy-phicalis/#eelviyd-a\' rel="nofollow ugc">eelviyd-a.anchor.com</a> [URL=http://mewkid.net/buy-phicalis/#eelviyd-u]eelviyd-u.anchor.com[/URL] http://mewkid.net/buy-phicalis/#eelviyd-t http://mewkid.net/buy-phicalis/#eelviyd-t http://mewkid.net/buy-phicalis/#eelviyd-t http://mewkid.net/buy-phicalis/#eelviyd-t http://mewkid.net/buy-phicalis/#eelviyd-t http://mewkid.net/buy-phicalis/#eelviyd-t http://mewkid.net/buy-phicalis/#eelviyd-t http://mewkid.net/buy-phicalis/#eelviyd-t ebodikd', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; rv:21.0) Gecko/20100101 Firefox/21.0', '', 0, 0),
(12, 1750, 'Hiram Hatten', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.120', '2019-12-05 08:12:58', '2019-12-05 07:12:58', 'Hi there! I realize this is somewhat off-topic however I had to ask.\r\nDoes running a well-established blog like yours require a large amount \r\nof work? I am brand new to blogging but I do write in my journal everyday.\r\n\r\nI\'d like to start a blog so I can share my experience and thoughts online.\r\nPlease let me know if you have any ideas or tips for brand new aspiring blog owners.\r\n\r\nThankyou!', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3427.0 Safari/537.36', '', 0, 0),
(13, 1750, 'Jerome Dougherty', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.66', '2019-12-06 08:35:46', '2019-12-06 07:35:46', 'Hey would you mind letting me know which hosting company you\'re \r\nworking with? I\'ve loaded your blog in 3 different \r\nbrowsers and I must say this blog loads a lot faster then most.\r\nCan you recommend a good web hosting provider at a fair price?\r\nKudos, I appreciate it!', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.7 Safari/537.36', '', 0, 0),
(14, 1750, 'Frederick Furr', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.130', '2019-12-06 12:47:40', '2019-12-06 11:47:40', 'This is my first time pay a visit at here and i am genuinely happy \r\nto read all at single place.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.7 Safari/537.36', '', 0, 0),
(15, 1671, 'apoupoyul', 'usoihetse@werwer.namnerbca.com', 'http://mewkid.net/where-is-xena/', '37.115.146.70', '2019-12-06 14:47:00', '2019-12-06 13:47:00', '[url=http://mewkid.net/where-is-xena/]Buy Amoxicillin Online[/url] <a href="http://mewkid.net/where-is-xena/" rel="nofollow ugc">Amoxicillin 500 Mg</a> rkb.smof.tariefchecker.be.aqc.jb http://mewkid.net/where-is-xena/', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36', '', 0, 0),
(16, 1671, 'ebamiace', 'iruketu@werwer.namnerbca.com', 'http://mewkid.net/where-is-xena/', '37.115.146.70', '2019-12-06 15:16:31', '2019-12-06 14:16:31', '[url=http://mewkid.net/where-is-xena/]Amoxicillin 500mg[/url] <a href="http://mewkid.net/where-is-xena/" rel="nofollow ugc">Amoxicillin Online</a> yft.hayf.tariefchecker.be.ywu.kx http://mewkid.net/where-is-xena/', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36 OPR/54.0.2952.64', '', 0, 0),
(17, 1750, 'Hosea Cardoza', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.120', '2019-12-07 11:09:47', '2019-12-07 10:09:47', 'Its such as you learn my thoughts! You seem to know so much about this, like you wrote the book in it \r\nor something. I feel that you simply can do with a few % \r\nto pressure the message home a little bit, but instead of that, this is excellent blog.\r\n\r\nAn excellent read. I will certainly be back.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; ; NCLIENT50_AAP38D0BEF49AF) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '', 0, 0),
(18, 1750, 'Isabella Curry', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2019-12-07 23:29:56', '2019-12-07 22:29:56', 'This blog was... how do you say it? Relevant!!\r\nFinally I have found something that helped me. Appreciate it!', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:45.9) Gecko/20100101 Goanna/3.0 Firefox/45.9 PaleMoon/27.0.2', '', 0, 0),
(19, 1750, 'Trey Arteaga', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.120', '2019-12-07 23:48:04', '2019-12-07 22:48:04', 'It is perfect time to make some plans for the future and \r\nit is time to be happy. I\'ve read this post and if I could I want to suggest you few interesting \r\nthings or suggestions. Maybe you can write next articles referring to this article.\r\nI wish to read more things about it!', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:45.9) Gecko/20100101 Goanna/3.0 Firefox/45.9 PaleMoon/27.0.2', '', 0, 0),
(20, 1750, 'Rosario Maas', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2019-12-08 05:45:26', '2019-12-08 04:45:26', 'If you want to obtain a great deal from this paragraph then you have to apply such methods \r\nto your won web site.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:45.9) Gecko/20100101 Goanna/3.0 Firefox/45.9 PaleMoon/27.0.2', '', 0, 0),
(21, 1750, 'Ilana Collins', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2019-12-08 16:36:01', '2019-12-08 15:36:01', 'Hi! I just wanted to ask if you ever have any issues with hackers?\r\nMy last blog (wordpress) was hacked and I ended up losing a few months of \r\nhard work due to no backup. Do you have any solutions to \r\nprevent hackers?', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:45.9) Gecko/20100101 Goanna/3.0 Firefox/45.9 PaleMoon/27.0.2', '', 0, 0),
(22, 1750, 'Trisha Macgroarty', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.66', '2019-12-09 17:20:15', '2019-12-09 16:20:15', 'Nice answer back in return of this query with firm arguments and \r\ndescribing everything about that.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0 Cyberfox/47.0.2', '', 0, 0),
(23, 1750, 'Lilliana Stjohn', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2019-12-10 07:26:54', '2019-12-10 06:26:54', 'Thanks for sharing your thoughts. I truly appreciate \r\nyour efforts and I am waiting for your next write ups thank you once again.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:52.0) Gecko/20100101 Firefox/4FD9', '', 0, 0),
(24, 1750, 'Stan De Garis', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.130', '2019-12-10 11:14:57', '2019-12-10 10:14:57', 'I visit everyday some web sites and websites to read content, except \r\nthis weblog provides quality based posts.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:52.0) Gecko/20100101 Firefox/4FD9', '', 0, 0),
(25, 1750, 'Celsa Grullon', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.120', '2019-12-10 12:15:41', '2019-12-10 11:15:41', 'Amazing issues here. I am very happy to look your post.\r\nThank you so much and I\'m looking forward to contact you.\r\nWill you please drop me a e-mail?', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:52.0) Gecko/20100101 Firefox/4FD9', '', 0, 0),
(26, 1750, 'Jeanna Lahey', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.66', '2019-12-11 00:57:36', '2019-12-10 23:57:36', 'There is certainly a great deal to find out about this subject.\r\nI really like all of the points you made.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:52.9) Gecko/20100101 Goanna/3.4 Firefox/52.9 PaleMoon/27.8.1', '', 0, 0),
(27, 1767, 'PaulJeoth', 'gwyn@probbox.com', 'https://elimite2.com/', '5.188.210.242', '2019-12-11 04:03:30', '2019-12-11 03:03:30', '<a href="https://elimite2.com/" rel="nofollow ugc">buy elimite cream over the counter</a>', 0, '0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36', '', 0, 0),
(28, 1767, 'MaryJeoth', 'mikeshawen@probbox.com', 'https://elimite2.com/', '5.188.210.242', '2019-12-11 06:38:51', '2019-12-11 05:38:51', '<a href="https://elimite2.com/" rel="nofollow ugc">can you buy elimite cream over the counter</a>', 0, '0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36 OPR/55.0.2994.44', '', 0, 0),
(29, 1750, 'Marie Sales', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.130', '2019-12-11 07:36:17', '2019-12-11 06:36:17', 'Hello everybody, here every person is sharing these kinds of knowledge,\r\nthus it\'s nice to read this website, and I used to pay a quick visit this weblog daily.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:52.9) Gecko/20100101 Goanna/3.4 Firefox/52.9 PaleMoon/27.8.1', '', 0, 0),
(30, 1750, 'Novella Stephens', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2019-12-11 19:57:21', '2019-12-11 18:57:21', 'What\'s Happening i am new to this, I stumbled upon this I have found \r\nIt absolutely useful and it has aided me out loads.\r\nI\'m hoping to contribute &amp; help other users like its aided \r\nme. Good job.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:52.9) Gecko/20100101 Goanna/3.4 Firefox/52.9 PaleMoon/27.8.1', '', 0, 0),
(31, 1750, 'Deborah Winslow', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2019-12-12 19:11:50', '2019-12-12 18:11:50', 'Hi there everybody, here every one is sharing such familiarity, thus it\'s fastidious to read \r\nthis website, and I used to pay a quick visit this web site \r\neveryday.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0', '', 0, 0),
(32, 1750, 'Dakota Niles', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.66', '2019-12-13 14:51:19', '2019-12-13 13:51:19', 'It\'s a shame you don\'t have a donate button! I\'d definitely donate to this fantastic blog!\r\n\r\nI suppose for now i\'ll settle for bookmarking and adding your RSS feed to my Google account.\r\n\r\nI look forward to fresh updates and will talk about this website with my Facebook group.\r\n\r\nTalk soon!', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.80 Safari/537.36 Core/1.47.516.400 QQBrowser/9.4.8186.400', '', 0, 0),
(33, 1642, 'Daniel Schillebeeks', 'daniel.schillebeeks@telenet.be', '', '84.195.94.182', '2019-12-14 00:11:40', '2019-12-13 23:11:40', 'Ik heb zonnepanelen en kan dit niet ingeven bij jullie.\r\ngraag had ik meer informatie gehad.\r\nMvg. Daniel\r\n\r\n0479472543', 0, '0', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36', '', 0, 0),
(34, 1750, 'Bradley Kirsch', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.130', '2019-12-14 06:31:21', '2019-12-14 05:31:21', 'Keep this going please, great job!', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 YaBrowser/16.9.1.1131 Yowser/2.5 Safari/537.36', '', 0, 0),
(35, 1750, 'Luann Hildebrant', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2019-12-14 07:52:04', '2019-12-14 06:52:04', 'Hello, I think your blog might be having browser compatibility issues.\r\nWhen I look at your blog site in Chrome, it looks fine but when opening in Internet Explorer, it has some overlapping.\r\nI just wanted to give you a quick heads up! Other then that,\r\namazing blog!', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 YaBrowser/16.9.1.1131 Yowser/2.5 Safari/537.36', '', 0, 0),
(36, 1750, 'Brittany Travers', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.120', '2019-12-14 11:01:41', '2019-12-14 10:01:41', 'I do not even know how I ended up here, but I thought this post was good.\r\n\r\nI do not know who you are but definitely you\'re going to \r\na famous blogger if you are not already ;) Cheers!', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 YaBrowser/16.9.1.1131 Yowser/2.5 Safari/537.36', '', 0, 0),
(37, 1750, 'Doyle Hardess', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.130', '2019-12-14 16:23:05', '2019-12-14 15:23:05', 'This piece of writing provides clear idea in favor of the new viewers of blogging, \r\nthat truly how to do blogging and site-building.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 YaBrowser/16.9.1.1131 Yowser/2.5 Safari/537.36', '', 0, 0),
(38, 1750, 'Maira Dominguez', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2019-12-14 21:27:22', '2019-12-14 20:27:22', 'For hottest news you have to visit world-wide-web and on the web I found this website as a best web site for newest updates.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 YaBrowser/16.9.1.1131 Yowser/2.5 Safari/537.36', '', 0, 0),
(39, 1750, 'Christina Martindale', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2019-12-15 09:31:30', '2019-12-15 08:31:30', 'Hi, I do believe your website may be having browser compatibility issues.\r\nWhenever I look at your web site in Safari, it looks fine however, when opening in I.E., it \r\nhas some overlapping issues. I just wanted to give you a \r\nquick heads up! Besides that, fantastic site!', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.104 Safari/537.36 Core/1.53.2759.400 QQBrowser/9.6.11266.400', '', 0, 0),
(40, 1750, 'Gia Belcher', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.130', '2019-12-15 11:03:15', '2019-12-15 10:03:15', 'It\'s remarkable for me to have a website, which is beneficial \r\nin favor of my experience. thanks admin', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.104 Safari/537.36 Core/1.53.2759.400 QQBrowser/9.6.11266.400', '', 0, 0),
(41, 1793, 'mysite', 'abbietarver@gmail.com', 'http://0009.in/user/profile/2779', '104.223.28.164', '2019-12-15 16:36:30', '2019-12-15 15:36:30', 'Wonderful blog! I found it while surfing around on Yahoo News.\r\nDo you have any suggestions on how to get listed in Yahoo News?\r\n\r\nI\'ve been trying for a while but I never seem to get \r\nthere! Many thanks', 0, '0', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Maxthon/4.9.4.3000 Chrome/39.0.2146.0 Safari/537.36', '', 0, 0),
(42, 1750, 'Anke Melson', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2019-12-16 03:15:11', '2019-12-16 02:15:11', 'Nice post. I learn something totally new and challenging on websites I stumbleupon on a daily basis.\r\nIt\'s always exciting to read content from \r\nother writers and use a little something from other sites.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.104 Safari/537.36 Core/1.53.3084.400 QQBrowser/9.6.11346.400', '', 0, 0),
(43, 1750, 'Blake Fulcher', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.66', '2019-12-18 15:36:56', '2019-12-18 14:36:56', 'Pretty! This has been an incredibly wonderful post.\r\nMany thanks for providing this info.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.104 Safari/537.36 Core/1.53.4882.400 QQBrowser/9.7.13036.400', '', 0, 0),
(44, 1750, 'Clifton Gepp', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.130', '2019-12-19 04:02:24', '2019-12-19 03:02:24', 'Hi my loved one! I wish to say that this article is amazing, great \r\nwritten and include approximately all significant infos.\r\nI would like to see more posts like this .', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.104 Safari/537.36 Core/1.53.4882.400 QQBrowser/9.7.13076.400', '', 0, 0),
(45, 1750, 'Bryon Abrahams', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.120', '2019-12-20 00:05:03', '2019-12-19 23:05:03', 'Great blog here! Also your website loads \r\nup very fast! What web host are you using? Can I \r\nget your affiliate link to your host? I wish my web site loaded up as fast as yours lol', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.104 Safari/537.36 Core/1.53.5006.400 QQBrowser/9.7.13080.400', '', 0, 0),
(46, 1750, 'Lavada Vigano', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.66', '2019-12-21 08:32:46', '2019-12-21 07:32:46', 'Great web site you\'ve got here.. It\'s difficult to find \r\nexcellent writing like yours nowadays. I really appreciate individuals like you!\r\nTake care!!', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.104 Safari/537.36 Core/1.53.5048.400 QQBrowser/9.7.13114.400', '', 0, 0),
(47, 1750, 'Ali Chew', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.66', '2019-12-21 19:04:53', '2019-12-21 18:04:53', 'Hey, I think your blog might be having browser \r\ncompatibility issues. When I look at your blog in Firefox, it looks \r\nfine but when opening in Internet Explorer,\r\nit has some overlapping. I just wanted to give you a quick \r\nheads up! Other then that, amazing blog!', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.104 Safari/537.36 Core/1.53.5048.400 QQBrowser/9.7.13114.400', '', 0, 0),
(48, 1750, 'Brandon Lieb', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2019-12-22 06:02:46', '2019-12-22 05:02:46', 'I am sure this post has touched all the internet users, its really really fastidious post \r\non building up new webpage.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.89 Safari/537.36 QQBrowser', '', 0, 0),
(49, 1750, 'Fredericka Worden', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.120', '2019-12-22 10:16:27', '2019-12-22 09:16:27', 'If you want to take much from this piece of writing then you have to apply such strategies to \r\nyour won blog.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.89 Safari/537.36 QQBrowser', '', 0, 0),
(50, 1750, 'Merissa Word', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2019-12-22 10:22:00', '2019-12-22 09:22:00', 'I do not even know the way I ended up right here, but I \r\nbelieved this submit was good. I do not understand who \r\nyou\'re however certainly you are going to a \r\nwell-known blogger if you aren\'t already. Cheers!', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.89 Safari/537.36 QQBrowser', '', 0, 0),
(51, 1750, 'Tamie McEachern', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2019-12-23 03:53:18', '2019-12-23 02:53:18', 'Way cool! Some very valid points! I appreciate you \r\npenning this article and also the rest of the website is really good.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.59 Safari/537.36 115Browser/8.3.0', '', 0, 0),
(52, 1750, 'Antonio Rigby', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.66', '2019-12-23 14:06:32', '2019-12-23 13:06:32', 'I am really grateful to the holder of this web site who \r\nhas shared this impressive paragraph at here.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.59 Safari/537.36 115Browser/8.3.0', '', 0, 0),
(53, 1750, 'Karla Clemes', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.120', '2019-12-23 14:16:16', '2019-12-23 13:16:16', 'I have been surfing online more than 2 hours today, yet I never found any \r\ninteresting article like yours. It is pretty worth enough for me.\r\n\r\nIn my view, if all web owners and bloggers made good content as you did, the web will be a lot \r\nmore useful than ever before.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.59 Safari/537.36 115Browser/8.3.0', '', 0, 0),
(54, 1750, 'Aundrea Bugnion', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.120', '2019-12-24 06:59:51', '2019-12-24 05:59:51', 'Thanks for your personal marvelous posting! I truly enjoyed reading it, you could be a \r\ngreat author.I will ensure that I bookmark your blog and may come \r\nback very soon. I want to encourage you to continue your great job, have \r\na nice morning!', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.59 Safari/537.36 115Browser/8.6.2', '', 0, 0),
(55, 1750, 'Von Amess', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2019-12-24 14:21:09', '2019-12-24 13:21:09', 'My coder is trying to persuade me to move to .net from PHP.\r\nI have always disliked the idea because of the expenses. But he\'s \r\ntryiong none the less. I\'ve been using WordPress on various websites for \r\nabout a year and am anxious about switching to another platform.\r\nI have heard good things about blogengine.net.\r\nIs there a way I can import all my wordpress content into it?\r\nAny help would be greatly appreciated!', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.59 Safari/537.36 115Browser/8.6.2', '', 0, 0),
(56, 1750, 'Jonnie Akhtar', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.130', '2019-12-24 14:55:25', '2019-12-24 13:55:25', 'What\'s up i am kavin, its my first time to commenting anywhere, when i read this paragraph i thought i \r\ncould also make comment due to this brilliant article.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.59 Safari/537.36 115Browser/8.6.2', '', 0, 0),
(57, 1750, 'Britney Hollis', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.66', '2019-12-25 01:56:22', '2019-12-25 00:56:22', 'After I initially commented I seem to have clicked the -Notify me when new \r\ncomments are added- checkbox and now every time a comment is added I recieve four emails with the same comment.\r\nPerhaps there is a way you can remove me from that service?\r\nThank you!', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36 Maxthon/5.1.5.2000', '', 0, 0),
(58, 1750, 'Grace Jessep', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.66', '2019-12-25 22:43:25', '2019-12-25 21:43:25', 'I was recommended this blog by my cousin. I am not sure whether this post is written by him as no one else know such detailed about my difficulty.\r\n\r\nYou\'re amazing! Thanks!', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 UBrowser/7.0.185.1002 Safari/537.36', '', 0, 0),
(59, 1750, 'Ismael Nimmo', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2019-12-25 23:50:56', '2019-12-25 22:50:56', 'Thank you a lot for sharing this with all people you really recognise what you\'re \r\ntalking approximately! Bookmarked. Please also visit my site \r\n=). We could have a hyperlink exchange arrangement between us', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 UBrowser/7.0.185.1002 Safari/537.36', '', 0, 0),
(60, 1793, 'blog', 'zac_venn@yahoo.de', 'http://ameblo.jp', '46.166.172.61', '2019-12-26 11:53:42', '2019-12-26 10:53:42', 'For the reason that the admin of this web page is \r\nworking, no hesitation very rapidly it will be famous, due to its quality contents.', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36', '', 0, 0),
(61, 1622, 'DESMEDT JAN', 'desmetjanalbert@me.com', '', '2a02:1811:8483:1800:d1ba:d847:5e5f:dbd8', '2019-12-26 15:03:05', '2019-12-26 14:03:05', 'Ik ben niet akkoord', 0, '0', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_2) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.4 Safari/605.1.15', '', 0, 0),
(62, 1750, 'Julieta Bollinger', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.130', '2019-12-27 00:12:22', '2019-12-26 23:12:22', 'After checking out a number of the blog articles on your web site, I really like your technique of blogging.\r\n\r\nI book marked it to my bookmark site list and will be checking back soon. Take \r\na look at my website too and let me know your opinion.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.96 Safari/537.36', '', 0, 0),
(63, 1750, 'Eusebia Becker', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.66', '2019-12-27 06:27:55', '2019-12-27 05:27:55', 'Hey! Do you know if they make any plugins to protect against hackers?\r\nI\'m kinda paranoid about losing everything I\'ve worked hard on. Any recommendations?', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.96 Safari/537.36', '', 0, 0),
(64, 1750, 'Natalie Gillon', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2019-12-27 22:58:30', '2019-12-27 21:58:30', 'I am not sure where you are getting your info, but good topic.\r\nI needs to spend some time learning more or understanding more.\r\nThanks for magnificent information I was looking for this information for my mission.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.90 Safari/537.36 2345Explorer/9.3.1.17322', '', 0, 0),
(65, 1750, 'Aundrea Slattery', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.130', '2019-12-28 08:13:37', '2019-12-28 07:13:37', 'Good info. Lucky me I ran across your site by accident (stumbleupon).\r\nI\'ve saved it for later!', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.90 Safari/537.36 2345Explorer/9.3.1.17322', '', 0, 0),
(66, 1750, 'Eden Clancy', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.66', '2019-12-28 15:25:43', '2019-12-28 14:25:43', 'Hi there to every body, it\'s my first visit of this webpage; this weblog consists of remarkable \r\nand actually good material designed for visitors.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.90 Safari/537.36 2345Explorer/9.3.1.17322', '', 0, 0),
(67, 1750, 'Elke Horniman', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.130', '2019-12-28 17:37:53', '2019-12-28 16:37:53', 'Do you mind if I quote a couple of your posts as long as I \r\nprovide credit and sources back to your webpage?\r\nMy blog site is in the exact same niche as yours and my visitors would genuinely benefit from some of the information you provide here.\r\nPlease let me know if this okay with you. Regards!', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.90 Safari/537.36 2345Explorer/9.3.1.17322', '', 0, 0),
(68, 1663, 'online casino', 'leonoratarenorerer@gawab.com', 'https://onlinecasinounion.us.com', '163.172.106.183', '2019-12-29 17:59:40', '2019-12-29 16:59:40', 'casino games online casino casino play [url=http://onlinecasinounion.us.com]casino online \r\nslots[/url] free casino games', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.183 Safari/537.36 Vivaldi/1.96.1147.42', '', 0, 0),
(69, 1767, 'free casino games', 'stephaniaredden@gmx.de', 'http://onlinecasinounion.us.com', '163.172.106.183', '2019-12-30 14:57:05', '2019-12-30 13:57:05', 'casino online free casino games no deposit \r\ncasino [url=http://onlinecasinounion.us.com]free casino games online[/url] online casino', 0, '0', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 UBrowser/5.5.5701.114 Safari/537.36', '', 0, 0),
(70, 1750, 'Jenna Pinson', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2019-12-30 16:06:53', '2019-12-30 15:06:53', 'Very good information. Lucky me I came across your blog by chance \r\n(stumbleupon). I have saved as a favorite for \r\nlater!', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.30 Safari/537.36 Core/1.59.3969.400 QQBrowser/10.0.184.400', '', 0, 0),
(71, 1750, 'Reuben Monson', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2019-12-31 09:16:10', '2019-12-31 08:16:10', 'Very great post. I simply stumbled upon your \r\nblog and wanted to mention that I\'ve truly loved surfing around \r\nyour weblog posts. In any case I\'ll be subscribing for your rss feed and I \r\nhope you write once more soon!', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.31 Safari/537.36', '', 0, 0),
(72, 1663, 'bezoehib', 'exkshixj@oiltempof.icu', 'https://cbdoilnumber1.com', '5.188.210.4', '2019-12-31 23:37:17', '2019-12-31 22:37:17', 'most reputable cbd oil supplier  cbd oil  <a href="https://cbdoilnumber1.com" rel="nofollow ugc">cbd oil  </a>  cbd oil cbd oil yaa health store  cbd oil \r\n \r\ntruebliss cbd oil  cbd oil  <a href="https://cbdoilnumber1.com" rel="nofollow ugc">cbd oil cbd oil vape </a>  cbd oil  cbd oil near me', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '', 0, 0),
(73, 1767, 'yermspes', 'bvohchbq@oiltempof.icu', 'https://cbdoilnumber1.com', '5.188.210.4', '2020-01-01 09:40:42', '2020-01-01 08:40:42', 'cbd oil  cbd oil  <a href="https://cbdoilnumber1.com" rel="nofollow ugc">cbd oil  </a>  kentucky farms cbd oil  what is cbd \r\n \r\ncbd oil yaa health  buy cbd oil cure cbd oil  <a href="https://cbdoilnumber1.com" rel="nofollow ugc">cbd oil cbd oil texas </a>  cbd labs  cbd oil hemp cbd oil', 0, '0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36', '', 0, 0),
(74, 1750, 'Anibal Speegle', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.66', '2020-01-02 23:56:46', '2020-01-02 22:56:46', 'I’m not that much of a internet reader to be honest but your \r\nsites really nice, keep it up! I\'ll go ahead and bookmark your \r\nwebsite to come back down the road. All the best', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.1.6000', '', 0, 0),
(75, 1582, 'mobile legend level 8 bypass', 'tangela.bastow@live.com', 'http://getjar-com-categories-all13850.blogstival.com/12652762/what-does-mobile-legends-mean', '72.249.124.150', '2020-01-03 03:56:52', '2020-01-03 02:56:52', 'Your mode of describing the whole thing in this article is truly good, all be capable \r\nof effortlessly know it, Thanks a lot.', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; rv:57.0) Gecko/20100101 Firefox/B8A7', '', 0, 0),
(76, 1750, 'Marcia Bernacchi', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2020-01-04 00:29:03', '2020-01-03 23:29:03', 'Way cool! Some extremely valid points! I appreciate you writing this post \r\nplus the rest of the website is also very good.', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/479B76', '', 0, 0),
(77, 1750, 'Florrie Tang', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.76', '2020-01-04 05:35:16', '2020-01-04 04:35:16', 'Hey there! This is kind of off topic but I need \r\nsome advice from an established blog. Is it difficult to \r\nset up your own blog? I\'m not very techincal but I can figure things out pretty fast.\r\nI\'m thinking about setting up my own but I\'m not sure where \r\nto start. Do you have any tips or suggestions?  Many thanks', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/479B76', '', 0, 0),
(78, 1582, 'mobile legend cosplay', 'lettiefenstermacher@freenet.de', 'http://mobilelegends66568.widblog.com/18560658/what-does-mobile-legends-mean', '104.144.201.130', '2020-01-04 22:42:24', '2020-01-04 21:42:24', 'My developer is trying to convince me to move to .net from PHP.\r\nI have always disliked the idea because of the expenses.\r\nBut he\'s tryiong none the less. I\'ve been using WordPress on a number \r\nof websites for about a year and am nervous about \r\nswitching to another platform. I have heard very good things about blogengine.net.\r\nIs there a way I can import all my wordpress content into it?\r\nAny help would be greatly appreciated!', 0, '0', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Maxthon/4.9.4.3000 Chrome/39.0.2146.0 Safari/537.36', '', 0, 0),
(79, 1750, 'Milla Elkins', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.130', '2020-01-06 08:59:55', '2020-01-06 07:59:55', 'Heya! I understand this is sort of off-topic however I needed to ask.\r\nDoes operating a well-established website \r\nlike yours take a large amount of work? I\'m completely new to running \r\na blog however I do write in my diary every day. I\'d like \r\nto start a blog so I can share my experience and thoughts online.\r\nPlease let me know if you have any ideas or tips for new aspiring bloggers.\r\nAppreciate it!', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.26 Safari/537.36 Core/1.63.4737.400 QQBrowser/10.0.654.400', '', 0, 0),
(80, 1750, 'Elinor Bernal', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.130', '2020-01-07 06:46:15', '2020-01-07 05:46:15', 'Right here is the perfect site for everyone who hopes to find out about this topic.\r\n\r\nYou know so much its almost tough to argue with you (not that I really would want to…HaHa).\r\n\r\nYou definitely put a brand new spin on a subject that\'s been discussed \r\nfor years. Wonderful stuff, just excellent!', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.26 Safari/537.36 Core/1.63.5083.400 QQBrowser/10.0.972.400', '', 0, 0),
(81, 1750, 'Michale Chirnside', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.66', '2020-01-07 10:36:07', '2020-01-07 09:36:07', 'I do trust all of the ideas you have offered to your post.\r\nThey are really convincing and will certainly work.\r\nStill, the posts are too brief for newbies. May just you please lengthen them a \r\nlittle from next time? Thank you for the post.', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.26 Safari/537.36 Core/1.63.5083.400 QQBrowser/10.0.972.400', '', 0, 0),
(82, 1750, 'Danielle Ehmann', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.130', '2020-01-07 11:16:34', '2020-01-07 10:16:34', 'Greetings! Very helpful advice in this particular \r\narticle! It\'s the little changes that will make \r\nthe most significant changes. Many thanks for sharing!', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.26 Safari/537.36 Core/1.63.5083.400 QQBrowser/10.0.972.400', '', 0, 0),
(83, 1750, 'Dan Unwin', 'amail@lmail.website', 'http://cialibuy.com', '5.188.84.66', '2020-01-07 20:59:11', '2020-01-07 19:59:11', 'I love your blog.. very nice colors &amp; theme. Did you \r\nmake this website yourself or did you hire someone to do it for you?\r\n\r\nPlz reply as I\'m looking to construct my own blog and would like \r\nto know where u got this from. appreciate it', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.26 Safari/537.36 Core/1.63.5083.400 QQBrowser/10.0.972.400', '', 0, 0),
(84, 1601, 'KelAwaimi', 'kelPayday@delays.space', 'http://cialibuy.com', '5.188.84.130', '2020-01-08 04:26:07', '2020-01-08 03:26:07', 'Cialis 5 Mg Giorni Alterni Amoxicillin And Pseudomonas Aeruginosa Prix Du Viagra En Algerie  <a href="http://cialibuy.com" rel="nofollow ugc">Buy Cialis</a> Pictures Of Amoxicillin Hives Cialis Sales', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36 OPR/54.0.2952.64', '', 0, 0),
(85, 1690, 'Fidelia', 'eartha.dove@gmail.com', 'https://www.marketwatch.com/press-release/best-keto-diet-pills-supplements-bhb-urgent-news-report-by-researched-reviews-2019-12-26', '172.96.90.117', '2020-01-11 00:44:55', '2020-01-10 23:44:55', 'It\'s an awesome article in favor of all the online people; thesy \r\nwill obtain avantage from it I am sure.', 0, '0', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.15 Safari/537.36', '', 0, 0),
(86, 1767, 'play online casino', 'karenludwick@t-online.de', 'https://onlinecasinounion.us.com', '163.172.106.183', '2020-01-12 08:34:08', '2020-01-12 07:34:08', 'online casino real money play online casino online casino \r\ngames [url=https://onlinecasinounion.us.com]free casino[/url] casino slots', 0, '0', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 SE 2.X MetaSr 1.0', '', 0, 0),
(87, 1767, 'play casino', 'gustavo_prince@gmail.com', 'https://onlinecasinounion.us.com', '163.172.106.183', '2020-01-13 16:38:54', '2020-01-13 15:38:54', 'online casino real money play casino free casino [url=https://onlinecasinounion.us.com]real money casino[/url] online casino \r\ngames', 0, '0', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36 OPR/51.0.2830.55 (Edition Campaign 34)', '', 0, 0),
(88, 1750, 'Lasonya Petterd', 'amail@lmail.website', 'http://cialibuy.com', '172.69.54.219', '2020-01-15 12:49:04', '2020-01-15 11:49:04', 'Good day! I know this is kinda off topic but I \r\nwas wondering which blog platform are you using for \r\nthis website? I\'m getting fed up of Wordpress because I\'ve had issues with hackers and \r\nI\'m looking at options for another platform. I would be awesome if you could point me in the direction of a good \r\nplatform.', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36 OPR/52.0.2871.64', '', 0, 0),
(89, 1750, 'Imogen Brunning', 'amail@lmail.website', 'http://cialibuy.com', '172.69.54.75', '2020-01-15 21:31:06', '2020-01-15 20:31:06', 'Hmm is anyone else experiencing problems with the pictures on this blog loading?\r\nI\'m trying to figure out if its a problem on my end or if \r\nit\'s the blog. Any suggestions would be greatly appreciated.', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36 OPR/52.0.2871.64', '', 0, 0),
(90, 1767, 'online casino games', 'sherlynrountree@gmail.com', 'https://onlinecasinounion.us.com', '141.101.104.179', '2020-01-15 22:54:00', '2020-01-15 21:54:00', 'casino online slots online casino games casino game \r\n[url=https://onlinecasinounion.us.com]real money casino[/url] casino slots', 0, '0', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36,gzip(gfe)', '', 0, 0),
(91, 1750, 'Dorthea Wymer', 'amail@lmail.website', 'http://cialibuy.com', '141.101.76.64', '2020-01-16 12:23:57', '2020-01-16 11:23:57', 'Hello there I am so delighted I found your site, I really found you by accident, while \r\nI was browsing on Bing for something else, Anyhow I am here now and would \r\njust like to say thank you for a marvelous post and \r\na all round enjoyable blog (I also love the theme/design),\r\nI don’t have time to read it all at the moment but I \r\nhave bookmarked it and also added in your RSS feeds, \r\nso when I have time I will be back to read much more,\r\nPlease do keep up the awesome b.', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36 OPR/52.0.2871.99', '', 0, 0),
(92, 1750, 'Bennett Pemberton', 'amail@lmail.website', 'http://cialibuy.com', '172.69.55.4', '2020-01-19 09:01:43', '2020-01-19 08:01:43', 'If you are going for finest contents like I do, simply pay \r\na visit this web page daily for the reason that it provides quality contents, thanks', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', 0, 0),
(93, 1750, 'Angus McGeehan', 'amail@lmail.website', 'http://cialibuy.com', '172.69.55.40', '2020-01-19 14:16:15', '2020-01-19 13:16:15', 'Hi! This post could not be written any better! Reading through this post reminds me of my good \r\nold room mate! He always kept talking about this.\r\n\r\nI will forward this post to him. Pretty sure he will have a good \r\nread. Thank you for sharing!', 0, '0', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', 0, 0) ;

#
# End of data contents of table `tf_comments`
# --------------------------------------------------------



#
# Delete any existing table `tf_display_files`
#

DROP TABLE IF EXISTS `tf_display_files`;


#
# Table structure of table `tf_display_files`
#

CREATE TABLE `tf_display_files` (
  `wpdf_id` int(11) NOT NULL AUTO_INCREMENT,
  `wpdf_title` varchar(255) DEFAULT NULL,
  `wpdf_mode` varchar(255) DEFAULT NULL,
  `wpdf_directory_setting` longtext,
  `wpdf_box_setting` longtext,
  `wpdf_drop_box_setting` longtext,
  `wpdf_amazon_setting` longtext,
  `wpdf_onedrive_setting` longtext,
  `wpdf_gdrive_setting` longtext,
  `wpdf_include_files` varchar(255) DEFAULT NULL,
  `wpdf_exclude_files` varchar(255) DEFAULT NULL,
  `wpdf_permissions_setting` text,
  `wpdf_template` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`wpdf_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;


#
# Data contents of table `tf_display_files`
#
INSERT INTO `tf_display_files` ( `wpdf_id`, `wpdf_title`, `wpdf_mode`, `wpdf_directory_setting`, `wpdf_box_setting`, `wpdf_drop_box_setting`, `wpdf_amazon_setting`, `wpdf_onedrive_setting`, `wpdf_gdrive_setting`, `wpdf_include_files`, `wpdf_exclude_files`, `wpdf_permissions_setting`, `wpdf_template`) VALUES
(9, '2019-NL', 'wpdf_mode_drop_box', 'a:1:{s:9:"wpdf_path";s:0:"";}', 'a:1:{s:11:"folder_name";s:0:"";}', 'a:2:{s:11:"folder_name";s:54:"/home/Tarieven/Tariefkaarten-Online/Tariefkaarten/2019";s:12:"dropbox_data";a:0:{}}', 'a:1:{s:11:"bucket_name";s:0:"";}', 'a:1:{s:11:"folder_name";s:0:"";}', 'a:1:{s:11:"folder_name";s:0:"";}', 'pdf', '', 'a:2:{s:18:"wpdf_require_login";s:2:"no";s:26:"wpdf_require_login_message";s:0:"";}', '') ;

#
# End of data contents of table `tf_display_files`
# --------------------------------------------------------



#
# Delete any existing table `tf_duplicator_packages`
#

DROP TABLE IF EXISTS `tf_duplicator_packages`;


#
# Table structure of table `tf_duplicator_packages`
#

CREATE TABLE `tf_duplicator_packages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `hash` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `owner` varchar(60) NOT NULL,
  `package` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hash` (`hash`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;


#
# Data contents of table `tf_duplicator_packages`
#
